package GeneticAlgorithms;

public class Gene<T> {


    public Double[] weights;

    public Double[] getWeights() {
        return weights;
    }

    public void setWeights(Double[] weights) {
        this.weights = weights;
    }
}
