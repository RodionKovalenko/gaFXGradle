package mnist;

//import javax.imageio.ImageIO;
//import java.awt.image.BufferedImage;
//import java.io.File;

public class ImageManipulation {


    public static void saveIntToImage(int [][] data, String path) throws Exception {
//        final int height = data.length;
//        final int width = data[0].length;
//        final BufferedImage image =
//                new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
//        for (int y = 0; y < height; ++y) {
//            for (int x = 0; x < width; ++x) {
//                image.setRGB(x, y, data[y][x]);
//            }
//        }
//        String workingDir = System.getProperty("user.dir");
//        String fullpath = workingDir + "/" + path;
//
//        new File(workingDir + "/" + path).mkdirs();
//
//        ImageIO.write(image, "png", new File(fullpath));
   }
}
